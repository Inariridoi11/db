package com.lastandfast.dbizi

/**
 * Bicis a buscar. Para actualizar: edita esta lista y vuelve a compilar.
 * La comparación es por valor, así que da igual el cero a la izquierda
 * (en pantalla la bici "0704" coincide con 704).
 */
object Targets {
    val set: Set<Int> = setOf(704, 710, 770, 776, 795, 798, 851, 1004, 1031, 1033, 1062, 1073, 1074, 1116, 1119, 1173, 1181, 1185, 1230, 1234, 1238, 1254, 1261)
}
