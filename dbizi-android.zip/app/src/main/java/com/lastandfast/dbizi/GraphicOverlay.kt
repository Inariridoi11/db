package com.lastandfast.dbizi

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import kotlin.math.max

/**
 * Dibuja los recuadros sobre la cámara mapeando las coordenadas de la
 * imagen analizada (vertical) al View con recorte central (fillCenter),
 * igual que hace PreviewView.
 */
class GraphicOverlay(context: Context, attrs: AttributeSet?) : View(context, attrs) {

    private var imgW = 0
    private var imgH = 0
    private var results: List<BikeResult> = emptyList()

    private val green = Color.rgb(61, 220, 78)
    private val blue = Color.rgb(31, 111, 214)
    private val gray = Color.rgb(150, 160, 168)

    private val matchStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 7f; color = green
    }
    private val greenStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 2.5f; color = gray
    }
    private val blueStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 2.5f; color = blue
        pathEffect = DashPathEffect(floatArrayOf(14f, 10f), 0f)
    }
    private val labelBg = Paint(Paint.ANTI_ALIAS_FLAG)
    private val labelTxt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(5, 35, 10); textSize = 44f; isFakeBoldText = true
    }
    private val smallTxt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textSize = 30f
    }

    fun setResults(width: Int, height: Int, list: List<BikeResult>) {
        imgW = width; imgH = height; results = list
        postInvalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (imgW == 0 || imgH == 0) return
        val scale = max(width.toFloat() / imgW, height.toFloat() / imgH)
        val offX = (imgW * scale - width) / 2f
        val offY = (imgH * scale - height) / 2f

        for (r in results) {
            val l = r.rect.left * scale - offX
            val t = r.rect.top * scale - offY
            val rt = r.rect.right * scale - offX
            val b = r.rect.bottom * scale - offY
            val box = RectF(l, t, rt, b)
            val label = String.format("%03d", r.number)

            when (r.kind) {
                Kind.MATCH -> {
                    canvas.drawRoundRect(box, 10f, 10f, matchStroke)
                    val txt = "✓ $label"
                    val tw = labelTxt.measureText(txt) + 22f
                    val lh = 58f
                    val ly = (t - lh - 12f).coerceAtLeast(0f)
                    labelBg.color = green
                    canvas.drawRoundRect(RectF(l, ly, l + tw, ly + lh), 8f, 8f, labelBg)
                    canvas.drawText(txt, l + 11f, ly + 42f, labelTxt)
                    // flecha apuntando a la bici
                    val ax = l + tw / 2f; val ay = ly + lh
                    val p = Path().apply {
                        moveTo(ax - 12f, ay); lineTo(ax + 12f, ay); lineTo(ax, ay + 16f); close()
                    }
                    labelBg.color = green
                    canvas.drawPath(p, labelBg)
                }
                Kind.BLUE -> {
                    canvas.drawRect(box, blueStroke)
                    canvas.drawText("azul $label", l, (t - 8f).coerceAtLeast(28f), smallTxt)
                }
                Kind.GREEN -> {
                    canvas.drawRect(box, greenStroke)
                    canvas.drawText(label, l, (t - 8f).coerceAtLeast(28f), smallTxt)
                }
            }
        }
    }
}
