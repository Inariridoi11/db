package com.lastandfast.dbizi

import android.graphics.Rect

enum class Kind { MATCH, GREEN, BLUE }

data class BikeResult(
    val rect: Rect,
    val number: Int,
    val kind: Kind
)
