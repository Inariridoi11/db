# dbizi scanner (Android nativo)

App minima: abres, apuntas la camara a las bicis dbizi y resalta en directo las **verdes**
cuyo numero esta en la lista. Las azules las lee pero las marca como "azul" y nunca cuentan.
OCR con **ML Kit on-device** (funciona sin internet). Los 23 numeros van cocidos dentro.

## Conseguir el APK sin instalar nada (GitHub Actions)
1. Crea un repo nuevo en GitHub y sube esta carpeta (push).
2. Pestana **Actions**: el workflow *build-apk* se ejecuta solo en cada push.
3. Al terminar (~3-5 min), entra en la ejecucion y descarga el artifact **dbizi-debug-apk**.
4. Pasalo al movil, abrelo e instala (Android pedira permitir "origenes desconocidos").

## O compilar en Android Studio
Abre la carpeta, deja que sincronice Gradle, y Run a tu movil (o Build > Build APK(s)).

## Actualizar los numeros
Edita `app/src/main/java/com/lastandfast/dbizi/Targets.kt`, cambia la lista y recompila.
